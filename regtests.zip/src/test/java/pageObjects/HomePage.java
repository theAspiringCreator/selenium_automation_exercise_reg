package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage{

	public HomePage(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(xpath="//a[contains(text(),'Signup / Login']")
	WebElement signUpLnk;

	
	public void clickLoginPage() {
		try 
		{
		signUpLnk.click();
		}
		catch(Exception e)
		{
		driver.get("https://www.automationexercise.com/login");	
		}
	}
}